//
//  Stock.swift
//  GetStockPrices
//
//  Created by Erigrigh on 12/10/22.
//

import Foundation

class Stock{
    var companyName: String = ""
    var symbol: String = ""
    var price: Float = 0.0
}
